Proyecto Final Aplicada 1.

Ventas en una ferretería.

Ventana Login.

Por defecto el Nombre Usuario: admin
Contraseña: admin

![Login](https://user-images.githubusercontent.com/64700344/89246668-a6b94280-d5d9-11ea-8078-ff7806b7dbf6.png)

Presiona en Ingresar si Nombre Usuario o Contraseña son incorrecta
recibirá un mensaje de error "Error Nombre Usuario o Contraseña incorrecta!".

Si Nombre Usuario y Contraseña son correcto se le mostrara el Menú Principal.

![Menu1](https://user-images.githubusercontent.com/64700344/89246765-dc5e2b80-d5d9-11ea-9278-caeffe4227ba.png)

Aquí tiene 2 opciones a elegir Registros y Consultas.

Opción Registros contiene las siguientes opciones:

Usuarios,
Clientes,
Ventas,
Compras,
Productos,
Vendedores,
Categorías,
Suplidores.

![Menu2](https://user-images.githubusercontent.com/64700344/89246824-f5ff7300-d5d9-11ea-884a-434befcb626e.png)


Opción Consultas contiene las siguientes opciones:

Consulta Usuarios,
Consulta Productos,
Consulta Vendedores,
Consulta Categorias,
Consulta Clientes,
Consulta Ventas

![Menu3](https://user-images.githubusercontent.com/64700344/89246883-13ccd800-d5da-11ea-879e-6112badd2fde.png)

